package com.chinotv.firetv;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import java.util.*;

public class MainActivity extends Activity {
    private ExoPlayer player;
    private LinearLayout root, controls;
    private PlayerView playerView;
    private TextView title;
    private boolean spanish = true;
    private String currentUrl = "";
    private final List<String[]> channels = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        player = new ExoPlayer.Builder(this).build();
        String saved = getPreferences(0).getString("channels", "");
        for (String line : saved.split("\\n")) {
            String[] parts = line.split("\\|", 2);
            if (parts.length == 2) channels.add(parts);
        }
        setup();
    }
    private Button button(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false);
        b.setOnClickListener(v -> r.run()); return b;
    }
    private void setup() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xff0e1422);
        title = new TextView(this); title.setText("CHINO TV  •  " + (spanish ? "Televisión internacional" : "International television"));
        title.setTextColor(-1); title.setTextSize(25); title.setGravity(Gravity.CENTER); title.setPadding(10, 12, 10, 12);
        root.addView(title);
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER);
        bar.addView(button(spanish ? "Añadir canal" : "Add channel", this::addChannel));
        bar.addView(button(spanish ? "Canales" : "Channels", this::showChannels));
        bar.addView(button(spanish ? "Audio" : "Audio", () -> selectLanguage(C.TRACK_TYPE_AUDIO)));
        bar.addView(button(spanish ? "Subtítulos" : "Subtitles", () -> selectLanguage(C.TRACK_TYPE_TEXT)));
        bar.addView(button("ES / EN", () -> { spanish = !spanish; setup(); }));
        root.addView(bar);
        playerView = new PlayerView(this); playerView.setPlayer(player); playerView.setUseController(true);
        root.addView(playerView, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView help = new TextView(this);
        help.setText(spanish ? "Agrega únicamente enlaces HTTPS autorizados (.m3u8 o video). Las pistas de audio/subtítulos dependen del canal." : "Add licensed HTTPS streams only (.m3u8 or video). Audio/subtitle choices depend on the stream.");
        help.setTextColor(0xffcccccc); help.setGravity(Gravity.CENTER); help.setPadding(12, 10, 12, 10);
        root.addView(help); setContentView(root);
    }
    private void addChannel() {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(24,0,24,0);
        EditText name = new EditText(this); name.setSingleLine(true); name.setHint(spanish ? "Nombre del canal" : "Channel name"); form.addView(name);
        EditText url = new EditText(this); url.setSingleLine(true); url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI); url.setHint("https://.../live.m3u8"); form.addView(url);
        new AlertDialog.Builder(this).setTitle(spanish ? "Nuevo canal autorizado" : "New licensed channel").setView(form)
            .setPositiveButton(spanish ? "Guardar" : "Save", (d,w) -> {
                String u = url.getText().toString().trim(); String n = name.getText().toString().trim();
                if (!u.startsWith("https://") || n.isEmpty() || n.contains("|")) { toast(spanish ? "Introduce nombre y URL HTTPS válida" : "Enter name and valid HTTPS URL"); return; }
                channels.add(new String[]{n,u}); save(); play(u);
            }).setNegativeButton(spanish ? "Cancelar" : "Cancel", null).show();
    }
    private void save() {
        StringBuilder s = new StringBuilder();
        for (String[] c : channels) s.append(c[0].replace("\n"," ")).append('|').append(c[1].replace("\n","")).append('\n');
        getPreferences(0).edit().putString("channels", s.toString()).apply();
    }
    private void showChannels() {
        if (channels.isEmpty()) { toast(spanish ? "Primero añade un canal autorizado" : "Add a licensed channel first"); return; }
        String[] options = new String[channels.size()];
        for (int i=0; i<channels.size(); i++) options[i] = channels.get(i)[0];
        new AlertDialog.Builder(this).setTitle(spanish ? "Mis canales" : "My channels").setItems(options, (d,i)->play(channels.get(i)[1]))
            .setNeutralButton(spanish ? "Eliminar canal" : "Remove channel", (d,w)->removeChannel()).show();
    }
    private void removeChannel() {
        String[] names = new String[channels.size()]; for (int i=0;i<names.length;i++) names[i]=channels.get(i)[0];
        new AlertDialog.Builder(this).setTitle(spanish ? "Eliminar" : "Remove").setItems(names, (d,i)->{ channels.remove(i);save(); }).show();
    }
    private void play(String url) {
        currentUrl = url;
        try { player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.play(); }
        catch (Exception e) { toast("Error: " + e.getMessage()); }
    }
    private void selectLanguage(int type) {
        List<String> labels = new ArrayList<>(); List<String> tags = new ArrayList<>();
        if (type == C.TRACK_TYPE_TEXT) { labels.add(spanish ? "Desactivar subtítulos" : "Disable subtitles"); tags.add("OFF"); }
        for (androidx.media3.common.Tracks.Group group : player.getCurrentTracks().getGroups()) {
            if (group.getType() != type) continue;
            for (int i=0;i<group.length;i++) {
                String lang = group.getTrackFormat(i).language;
                if (lang != null && !lang.isEmpty() && !tags.contains(lang)) {
                    tags.add(lang); labels.add(lang.equals("es") ? "Español" : lang.equals("en") ? "English" : lang);
                }
            }
        }
        if (labels.isEmpty()) { toast(spanish ? "El canal no ofrece pistas alternativas" : "No alternate tracks available"); return; }
        new AlertDialog.Builder(this).setTitle(type==C.TRACK_TYPE_AUDIO ? "Audio" : (spanish ? "Subtítulos" : "Subtitles"))
            .setItems(labels.toArray(new String[0]), (d,which)->{
                String tag = tags.get(which);
                androidx.media3.common.TrackSelectionParameters.Builder b=player.getTrackSelectionParameters().buildUpon();
                if (type==C.TRACK_TYPE_TEXT) {
                    b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, "OFF".equals(tag));
                    if (!"OFF".equals(tag)) b.setPreferredTextLanguage(tag);
                } else b.setPreferredAudioLanguage(tag);
                player.setTrackSelectionParameters(b.build());
            }).show();
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    @Override protected void onStop() { super.onStop(); player.pause(); }
    @Override protected void onDestroy() { player.release(); super.onDestroy(); }
}
